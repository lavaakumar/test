﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Script.Serialization;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [RoutePrefix("TSRoute")]
    public class tsController : ApiController
    {
        tsData client = null;


        [Route("Save")]
        [HttpPost]
        public void  Save(HttpRequestMessage request, object tsInddtls)
        {
            //return null;// "Data Reached";
            

            var testModels = JsonConvert.DeserializeObject<List<TSInddtls>>(tsInddtls.ToString());
        }

        //[Route("submitdata")]
        //[HttpPost]
        //public string submitdata(GetAll ga)
        //{
        //    return "Data Reached";
        //}


        [Route("New")]
        [HttpGet]
        public List<TSInddtls> createNewTS(HttpRequestMessage request)
        {
            DataTable dt = new DataTable();
            List<TSInddtls> list = new List<TSInddtls>();
            TSInddtls tsInd = new TSInddtls();
            


            list.Add(tsInd);

            return list;
        }


        [Route("loadPrj")]
        [HttpGet]
        public List<Projects> lPrdd(HttpRequestMessage request)
        {
           return  new tsData().loadPrj(DateTime.Now.AddDays(-10), DateTime.Now).ToList();
        }
        [Route("loadTsk")]
        [HttpGet]
        public List<Tasks> lTadd(HttpRequestMessage reques,Object prjId)
        {
            return new tsData().loadtasks(DateTime.Now.AddDays(-10), DateTime.Now, prjId.ToString()).ToList();
        }

        [Route("loadRes")]
        [HttpGet]
        public List<Resources> lredd(HttpRequestMessage request, Object strblock)
        {
            return new tsData().loadResrcs(strblock.ToString()).ToList();
        }



       


    }
}