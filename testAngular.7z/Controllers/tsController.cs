﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Script.Serialization;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [RoutePrefix("TSRoute")]
    public class tsController : ApiController
    {
        tsData client = null;


        [Route("Save")]
        [HttpPost]
        public void  Save(HttpRequestMessage request, object tsInddtls)
        {
            //return null;// "Data Reached";
            

            var testModels = JsonConvert.DeserializeObject<List<TSInddtls>>(tsInddtls.ToString());
        }

        //[Route("submitdata")]
        //[HttpPost]
        //public string submitdata(GetAll ga)
        //{
        //    return "Data Reached";
        //}


        [Route("New")]
        [HttpGet]
        public List<TSInddtls> createNewTS(HttpRequestMessage request)
        {
            var queryStrings = request.GetQueryStrings();
            if (queryStrings == null)
                return null;



            DataTable dt = new DataTable();
            List<TSInddtls> list = new List<TSInddtls>();
            TSInddtls tsInd = new TSInddtls();
            tsInd.MoReg = 8;
            tsInd.MoOT = 8;
            tsInd.MoDT = 8;
            tsInd.DDProj = new tsData().loadPrj(DateTime.Now.AddDays(-10), DateTime.Now).ToList();
            tsInd.DDRes = new tsData().loadResrcs(queryStrings["u_blk"]).ToList();
            list.Add(tsInd);

            return list;
        }


        [Route("loadPrj")]
        [HttpGet]
        public List<Projects> lPrdd(HttpRequestMessage request)
        {
           return  new tsData().loadPrj(DateTime.Now.AddDays(-10), DateTime.Now).ToList();
        }
        [Route("loadTsk")]
        [HttpGet]
        public List<Tasks> lTadd(HttpRequestMessage request)
        {
            var queryStrings = request.GetQueryStrings();
            if (queryStrings == null)
                return null;

            return new tsData().loadtasks(DateTime.Now.AddDays(-10), DateTime.Now, queryStrings["u_prj"]).ToList();
        }

        [Route("loadRes")]
        [HttpGet]
        public List<Resources> lredd(HttpRequestMessage request, Object strblock)
        {


            return new tsData().loadResrcs(strblock.ToString()).ToList();
        }



       


    }
}