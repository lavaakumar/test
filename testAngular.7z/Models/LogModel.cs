﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebApplication2.Models
{
    public class Logger
    {
        private string filePath = string.Empty;
        private string AEFilePath = string.Empty;
        private string DIOFilePath = string.Empty;
        private string LETFilePath = string.Empty;
        private string configFilePath = string.Empty;
        private string runtimeFilePath = string.Empty;
        //private string errorFilePath = "";

        //create an instance of streamwriter
        private StreamWriter sw;

        private bool combined_logs = false;
        private bool log_AE = true;
        private bool log_DIO = true;
        private bool log_LET = true;
        //private bool log_EXT = true;
        private bool log_configuration = true;
        private bool log_runtime = true;

        //record what the year, month and day was when the log was opened...
        private DateTime date_at_opening;

        public Logger()
        {
            //if directory does not exist, create the directory
            if (!Directory.Exists("C:\\\\HondaEGA\\Timesheets\\" + DateTime.Today.Year + "\\" + DateTime.Today.Month + "\\" + DateTime.Today.Day))
            {
                Directory.CreateDirectory("C:\\\\HondaEGA\\Timesheets\\" + DateTime.Today.Year + "\\" + DateTime.Today.Month + "\\" + DateTime.Today.Day);
            }

            //set to default values so the openlog works properly
            date_at_opening = DateTime.Parse("1 jan 1900");
        }

        ~Logger()
        {
            //close the logger
            this.CloseLog();
        }


        //OpenLog - opens the log for writing
        //=============================================================================================================
        public void OpenLog(string path)
        {

            filePath = path;

            try
            {
                //if any of the years, months or days are different, then we need to revalidate the whole filepath, etc.
                //else we can skip this altogether...
                if (this.date_at_opening != DateTime.Today)
                {

                    //"C:\\\\PPCToolLog\\"

                    this.runtimeFilePath = path + DateTime.Today.Year + "\\" + DateTime.Today.Month + "\\" + DateTime.Today.Day
                        + "\\" + DateTime.Today.Year + DateTime.Today.Month + DateTime.Today.Day + "Runtime_Log.txt";



                    //    this.DIOFilePath = DateTime.Today.Year + "\\" + DateTime.Today.Month + "\\" + DateTime.Today.Day
                    //        + "\\" + DateTime.Today.Year + DateTime.Today.Month + DateTime.Today.Day + "stats.txt";


                    ////date opened history, check to see if we need to actually reopen...
                    //date_at_opening = DateTime.Today;

                    //Debug.WriteLine("filepath=" + filePath.ToString());

                    //this.errorFilePath = DateTime.Today.Year + "\\" + DateTime.Today.Month + "\\" + DateTime.Today.Day
                    //        + "\\" + DateTime.Today.Year + DateTime.Today.Month + DateTime.Today.Day + "LWLIF_Error_Log.txt";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }//end ========================================================================================================


        //CloseLog - closes the logger, used in destructor
        //=============================================================================================================
        public void CloseLog()
        {
            if (sw != null)
            {
                try
                {
                    sw.Close();
                    sw = null;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }//end ========================================================================================================

        //Log_Data_String - writes date, component, and string data to the log file
        //=============================================================================================================
        public void Log_Data_String(string component, string data)
        {
            try
            {
                //check the filepath again, because we might have changed days
                //if directory does not exist, create the directory
                if (!Directory.Exists(filePath + DateTime.Today.Year + "\\" + DateTime.Today.Month + "\\" + DateTime.Today.Day))
                {
                    Directory.CreateDirectory(filePath + DateTime.Today.Year + "\\" + DateTime.Today.Month + "\\" + DateTime.Today.Day);
                }
                //perform an openlog(), which will write the data to the proper path
                //this.OpenLog();

                //initialize streamwriter
                if (this.combined_logs)
                {
                    sw = new StreamWriter(filePath, true);
                }
                else
                {
                    if ((component == "DIO") && (log_DIO == true))
                    {
                        sw = new StreamWriter(DIOFilePath, true);
                    }
                    else if ((component == "AE") && (log_AE == true))
                    {
                        sw = new StreamWriter(AEFilePath, true);
                    }
                    else if ((component == "LET") && (log_LET == true))
                    {
                        sw = new StreamWriter(LETFilePath, true);
                    }
                    else if ((component == "CONFIG") && (log_configuration == true))
                    {
                        sw = new StreamWriter(configFilePath, true);
                    }
                    else if ((component == "RUNTIME") && (log_runtime == true))
                    {
                        sw = new StreamWriter(runtimeFilePath, true);
                    }
                }
                if (data.Length > 0)
                {
                    //write output data
                    sw.WriteLine(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "." + DateTime.Now.Millisecond.ToString("000") + ", " + component + ": " + data);
                    //sw.WriteLine(data);
                }
                else
                {
                    sw.WriteLine("");
                }
                sw.Close();
            }
            catch (Exception er)
            {
                //Debug.WriteLine("Error writing to file.  Actual Exception: " + er.ToString());
            }
        }//end ========================================================================================================

        public static void WriteToErrorLog(String Module, String Method, String ErrorMessage, String ErrorStack, DateTime ErrorTime)
        {

            String logLocation = "C:\\\\HondaEGA\\Timesheets\\" + DateTime.Today.Year + "\\" + DateTime.Today.Month + "\\" + DateTime.Today.Day + "\\";
            StreamWriter writer = null;

            try
            {

                if (Directory.Exists(logLocation) == false) Directory.CreateDirectory(logLocation);


                writer = new StreamWriter(logLocation + Path.DirectorySeparatorChar + "Error Log.txt", true);


                writer.WriteLine(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + "." + DateTime.Now.Millisecond.ToString("000") + " in " +
                                 Module + "." + Method + ":\t" + ErrorMessage + Environment.NewLine +
                                 "\t" + ErrorStack.Replace(Environment.NewLine, Environment.NewLine + "\t"));


            }
            catch (Exception ex)
            {
                //MessageBox.Show("An error occurred while adding a message to the Error Log:" + Environment.NewLine + Environment.NewLine +
                              //  "\t" + ex.Message + Environment.NewLine + Environment.NewLine + ex.StackTrace);

            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                    writer.Dispose();
                    writer = null;
                }
            }

        }

    }
}
