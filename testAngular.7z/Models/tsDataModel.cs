﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;

namespace WebApplication2.Models
{
    public class tsData : IDisposable
    {


        private SqlConnection myConnection = new SqlConnection();

        Logger log = new Logger();

        bool logging_enabled = true;

        string logging_path = "C:\\\\HondaEGA\\TimeSheets\\";

        bool connect_log_displayed = false;

        string connection_string = String.Empty;

        string database_name = "D2ProjectCost";
        
        public String DatabaseName
        {
            get { return database_name; }
        }

        public tsData()
        {

            //database_name = DBName;

            connection_string =

                //   "user id = HSDSDbUser" + ";" +
                //"password = #5%5NotMe" + ";" +
                //"Network Address = SQLVM" + ";" +
                //"Trusted_Connection = no" + ";" +
                //"database = D2ProjectCost_Dev" + "; " +
                //"connection timeout = 3 ";

                "Network Address= egasql01" + ";" +
                "Trusted_Connection= yes;" +
                "database= " + database_name + "; " +
                "MultipleActiveResultSets=true;" +
                "connection timeout= 3";


        }


        public bool Is_Connected()
        {
            if (myConnection.State.ToString() == "Open")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Connect()
        {
            if (logging_enabled == true)
            {
                log.OpenLog(logging_path);
            }
            //log.OpenLog("C:\\\\PPCToolLog\\");

            myConnection = new SqlConnection(connection_string);


            log_text("RUNTIME", "Connection String: " + myConnection.ConnectionString);

            try
            {
                myConnection.Open();

                log_text("RUNTIME", "Connected to database");
            }
            catch (Exception ex)
            {

                if (connect_log_displayed == false)
                {
                    //MessageBox.Show("Error connecting to the database. :(  \n\nCheck the error log for more detials ");
                    connect_log_displayed = true;
                }
                log_text("RUNTIME", "Could not open a connection: " + ex.ToString());
            }

            log.CloseLog();

            return true;
        }

        public void log_text(string log_file, string text)
        {
            if (logging_enabled)
            {
                log.Log_Data_String(log_file, text);
            }
        }

        //----------------------------------Classes-----------------------------------------------

        public IEnumerable<Projects> loadPrj(DateTime dtStartDate, DateTime dtEndDate)
        {
            List<Projects> project = new List<Projects>();
            if (Is_Connected() == false) Connect();
            using (var cmd = this.myConnection.CreateCommand())
            {
               // conn.Open();
                cmd.CommandText = "proc_GetWebActiveProjects";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StartDate", dtStartDate);
                cmd.Parameters.AddWithValue("@EndDate", dtEndDate);
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Projects prj =   new Projects
                        {
                            id = reader.GetString(reader.GetOrdinal("PN")),
                            value = reader.GetString(reader.GetOrdinal("ProjectNumber")),
                        };
                        project.Add(prj);
                    };
                }
            }
            return project;

        }

        public IEnumerable<Tasks> loadtasks(DateTime dtStartDate, DateTime dtEndDate,string pn)
        {
            List<Tasks> task = new List<Tasks>();
            if (Is_Connected() == false) Connect();
            using (var cmd = this.myConnection.CreateCommand())
            {
                // conn.Open();
                cmd.CommandText = "proc_GetWebProjTasks";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@StartDate", dtStartDate);
                cmd.Parameters.AddWithValue("@EndDate", dtEndDate);
                cmd.Parameters.AddWithValue("@Project_Number", pn);
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Tasks tsk = new Tasks
                        {
                            id = reader.GetString(reader.GetOrdinal("TN")),
                            value = reader.GetString(reader.GetOrdinal("TaskNumber")),
                        };
                        task.Add(tsk);
                    };
                }
            }
            task.Insert(0, new Tasks { id = string.Empty, value = string.Empty });
            return task;

        }

        public IEnumerable<Resources> loadResrcs(string strBlock)
        {
            List<Resources> resource = new List<Resources>();
            if (Is_Connected() == false) Connect();
            using (var cmd = this.myConnection.CreateCommand())
            {
                // conn.Open();
                cmd.CommandText = "select Resource from TS_Resource where Block = '" + strBlock + "'";
             
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Resources res = new Resources
                        {
                            id = reader.GetString(reader.GetOrdinal("Resource")),
                            value = reader.GetString(reader.GetOrdinal("Resource")),
                        };
                        resource.Add(res);
                    };
                }
            }
            return resource;
        }


        //public DataTable dtGetResources(string strBlock)
        //{
        //    DataTable table = new DataTable();
        //    SqlDataAdapter adapter = null;
        //    String query;

        //    try
        //    {

        //        if (Is_Connected() == false) Connect();


        //        query = "SELECT Resource " +
        //                "FROM [" + this.database_name + "].[dbo].[TS_Resource] where Block = '" + strBlock + "'";

        //        adapter = new SqlDataAdapter(query, myConnection);


        //        log_text("RUNTIME", "Running query in \"" + System.Reflection.MethodInfo.GetCurrentMethod().Name + "\":\t" + query);

        //        adapter.Fill(table);

        //    }
        //    catch (Exception ex)
        //    {
        //        log_text("RUNTIME", "Trouble running query in \"" + System.Reflection.MethodInfo.GetCurrentMethod().Name + "\":" + Environment.NewLine + "\t" + ex.ToString().Replace(Environment.NewLine, Environment.NewLine + "\t"));
        //        Write_Error(MethodBase.GetCurrentMethod(), ex);
        //    }
        //    finally
        //    {
        //        if (adapter != null)
        //        {
        //            adapter.Dispose();
        //            adapter = null;
        //        }

        //        query = null;
        //    }


        //    return table;

        //}

        //public DataTable Load_Projects(DateTime dtStartDate, DateTime dtEndDate)
        //{
        //    DataTable returnTable = new DataTable();
        //    SqlCommand myCommand = null;
        //    SqlDataAdapter adapter = new SqlDataAdapter();

        //    if (!Is_Connected())
        //    {

        //        Connect();

        //    }

        //    myCommand = new SqlCommand("proc_GetWebActiveProjects", this.myConnection);
        //    myCommand.CommandType = CommandType.StoredProcedure;
        //    myCommand.CommandText = "proc_GetActiveProjects";
        //    myCommand.Parameters.AddWithValue("@StartDate", dtStartDate);
        //    myCommand.Parameters.AddWithValue("@EndDate", dtEndDate);


        //    myCommand.ExecuteNonQuery();
        //    adapter.SelectCommand = myCommand;
        //    adapter.Fill(returnTable);

        //    log_text("RUNTIME", "Running query: " + myCommand.CommandText);
        //    SqlDataReader myReader = null;

        //    try
        //    {


        //        return returnTable;
        //    }
        //    catch (Exception ex)
        //    {
        //        log_text("RUNTIME", "Trouble running query: " + ex.ToString());
        //        //MessageBox.Show(ex.ToString(), "SQL Exception", MessageBoxButtons.OK);

        //        try
        //        {
        //            myReader.Dispose();
        //        }
        //        catch { }

        //        //return returnTable;


        //        throw;
        //    }

        //}


        //public DataTable dtGetProjTasks(DateTime dtStartDate, DateTime dtEndDate)
        //{
        //    DataTable returnTable = new DataTable();
        //    SqlCommand myCommand = null;
        //    SqlDataAdapter adapter = new SqlDataAdapter();

        //    try
        //    {
        //        if (Is_Connected() == false) Connect();

        //        myCommand = new SqlCommand("proc_GetWebProjTasks", this.myConnection);
        //        myCommand.CommandType = CommandType.StoredProcedure;
        //        myCommand.CommandText = "proc_GetProjTasks";
        //        myCommand.Parameters.AddWithValue("@StartDate", dtStartDate);
        //        myCommand.Parameters.AddWithValue("@EndDate", dtEndDate);


        //        myCommand.ExecuteNonQuery();
        //        adapter.SelectCommand = myCommand;
        //        adapter.Fill(returnTable);
        //    }
        //    catch (Exception ex)
        //    {
        //        log_text("RUNTIME", "Trouble running query in \"" + System.Reflection.MethodInfo.GetCurrentMethod().Name + "\":" + Environment.NewLine + "\t" + ex.ToString().Replace(Environment.NewLine, Environment.NewLine + "\t"));
        //        Write_Error(MethodBase.GetCurrentMethod(), ex);
        //        Console.WriteLine("trouble");
        //        Console.WriteLine(ex.ToString());

        //    }
        //    return returnTable;

        //}

        public DataSet dsGetTSDetails(int iTimeCardID)
        {
            DataSet returnTable = new DataSet();
            SqlCommand myCommand = null;
            SqlDataAdapter adapter = new SqlDataAdapter();

            try
            {
                if (Is_Connected() == false) Connect();

                myCommand = new SqlCommand("proc_GetTSDetails", this.myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;
                myCommand.CommandText = "proc_GetTSDetails";

                myCommand.Parameters.AddWithValue("@TimecardID", iTimeCardID);

                myCommand.ExecuteNonQuery();
                adapter.SelectCommand = myCommand;
                adapter.Fill(returnTable);
            }
            catch (Exception ex)
            {
                log_text("RUNTIME", "Trouble running query in \"" + System.Reflection.MethodInfo.GetCurrentMethod().Name + "\":" + Environment.NewLine + "\t" + ex.ToString().Replace(Environment.NewLine, Environment.NewLine + "\t"));
                Write_Error(MethodBase.GetCurrentMethod(), ex);
            }
            return returnTable;

        }



        public void Write_Error(MethodBase MethodOccurredIn, Exception Ex)
        {
            SqlCommand command = null;
            String errorData = null;
            String query = null;

            try
            {

                if (Ex.Data.Keys.Count == 0)
                    errorData = String.Empty;
                else
                    foreach (String dataKey in Ex.Data.Keys)
                        errorData += dataKey + ":  \t" + Ex.Data[dataKey] + Environment.NewLine;


                query = "INSERT INTO [" + database_name + "].[dbo].[Error] " +
                                  "( [Application], [Module], [Method], [UserName], [ErrorTime], " +
                                    "[ErrorMessage], [ErrorStack], [ErrorSource], [ErrorTarget], [ErrorData] ) " +
                           "VALUES ( 'PPC Tool' , " +
                                    "'" + MethodOccurredIn.Module.Name.Replace("'", "''") + "' , " +
                                    "'" + MethodOccurredIn.Name.Replace("'", "''") + "' , " +
                                    "'" + Environment.UserName.Replace("'", "''") + "' , " +
                                    "'" + DateTime.Now + "' , " +
                                    "'" + Ex.Message.Replace("'", "''") + "' , " +
                                    "'" + Ex.StackTrace.Replace("'", "''") + "' , " +
                                    "'" + Ex.Source.Replace("'", "''") + "' , " +
                                    "'" + Ex.TargetSite.ToString().Replace("'", "''") + "' , " +
                                    "'" + errorData.Replace("'", "''") + "' )";


                if (Is_Connected() == false) Connect();


                command = new SqlCommand(query, this.myConnection);


                log_text("RUNTIME", "Running query in \"" + System.Reflection.MethodInfo.GetCurrentMethod().Name + "\":\t" + command.CommandText);

                command.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
               // MsgBox.Msg(ex.ToString());
            }
            finally
            {
                if (command != null)
                {
                    command.Dispose();
                    command = null;
                }

                query = null;
            }

        }
        
        public bool Read_DidUserCreateThisTimecard(String iTimeCardId)
        {
            bool bReturn = false;
            SqlCommand command = null;
            String query;
            try
            {
                if (Is_Connected() == false) Connect();

                query = "SELECT Count('') " +
                        "FROM [" + database_name + "].[dbo].[TS_Timecard] " +
                        "WHERE [TimecardID] = " + iTimeCardId + " AND " +
                              "[CreatedBy] = '" + Environment.UserName + "' ";

                command = new SqlCommand(query, myConnection);
                command.ExecuteNonQuery();


                bReturn = (int.Parse(command.ExecuteScalar().ToString()) == 1);


            }
            catch (Exception ex)
            {
                bReturn = false;
                log_text("RUNTIME", "Trouble running query in \"" + System.Reflection.MethodInfo.GetCurrentMethod().Name + "\":" + Environment.NewLine + "\t" + ex.ToString().Replace(Environment.NewLine, Environment.NewLine + "\t"));
                //Write_Error(MethodBase.GetCurrentMethod(), ex);
                throw;
            }
            finally
            {
                if (command != null)
                {
                    command.Dispose();
                    command = null;
                }

                query = null;
            }

            return bReturn;
        }


        public string Check_ProjectApproval(String ProjectNumber)
        {
            string prjNo = string.Empty;
            SqlCommand myCommand = null;
            //   String query;
            try
            {
                if (Is_Connected() == false) Connect();



                myCommand = new SqlCommand("proc_IsProjectOpen", this.myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;
                myCommand.CommandText = "proc_IsProjectOpen";
                myCommand.Parameters.AddWithValue("@ProjectNumber", ProjectNumber);

                // var obj = myCommand.ExecuteScalar();

                // prjNo = (myCommand.ExecuteScalar()==null)?string.Empty: myCommand.ExecuteScalar().ToString();
                prjNo = ConvertFromDBVal<string>(myCommand.ExecuteScalar());

            }
            catch (Exception ex)
            {
                prjNo = string.Empty;
                log_text("RUNTIME", "Trouble running query in \"" + System.Reflection.MethodInfo.GetCurrentMethod().Name + "\":" + Environment.NewLine + "\t" + ex.ToString().Replace(Environment.NewLine, Environment.NewLine + "\t"));
                //Write_Error(MethodBase.GetCurrentMethod(), ex);
                throw;
            }
            finally
            {
                if (myCommand != null)
                {
                    myCommand.Dispose();
                    myCommand = null;
                }

            }

            return prjNo;
        }

        public string Check_IsTaskValid(String ProjectNumber, String Task, DateTime timecarddate)
        {
            string taskNo = string.Empty;
            SqlCommand myCommand = null;
            // String query;
            try
            {
                if (Is_Connected() == false) Connect();



                myCommand = new SqlCommand("proc_IsTaskValid", this.myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;
                myCommand.CommandText = "proc_IsTaskValid";
                myCommand.Parameters.AddWithValue("@ProjectNumber", ProjectNumber);
                myCommand.Parameters.AddWithValue("@TaskNumber", Task);
                myCommand.Parameters.AddWithValue("@Timecarddate", timecarddate);

                taskNo = ConvertFromDBVal<string>(myCommand.ExecuteScalar());




            }
            catch (Exception ex)
            {
                taskNo = string.Empty;
                log_text("RUNTIME", "Trouble running query in \"" + System.Reflection.MethodInfo.GetCurrentMethod().Name + "\":" + Environment.NewLine + "\t" + ex.ToString().Replace(Environment.NewLine, Environment.NewLine + "\t"));
                //Write_Error(MethodBase.GetCurrentMethod(), ex);
                throw;
            }
            finally
            {
                if (myCommand != null)
                {
                    myCommand.Dispose();
                    myCommand = null;
                }

            }

            return taskNo;
        }

        public static T ConvertFromDBVal<T>(object obj)
        {
            if (obj == null || obj == DBNull.Value)
            {
                return default(T); // returns the default value for the type
            }
            else
            {
                return (T)obj;
            }
        }
        public void Dispose()
        {
            myConnection.Dispose();
        }
    }
}
