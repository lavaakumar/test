﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    //public class tsModel
    //{
        public class Projects
        {
            public string id { get; set; }
            public string value { get; set; }
        }
        public class Tasks
        {
            public string id { get; set; }
            public string value { get; set; }
        }
        public class Resources
        {
            public string id { get; set; }
            public string value { get; set; }
        }
        public class TSInddtls
        {
            public int tcId { get; set; }
            public string prj { get; set; }
            public string tsk { get; set; }
            public string res { get; set; }
            public string empId { get; set; }
            public string wd { get; set; }

        public double MoReg { get; set; }
        public double MoOT { get; set; }
        public double MoDT { get; set; }


        public double TuReg { get; set; }
        public double TuOT { get; set; }
        public double TuDT { get; set; }

        public double WeReg { get; set; }
        public double WeOT { get; set; }
        public double WeDT { get; set; }

        public double ThReg { get; set; }
        public double ThOT { get; set; }
        public double ThDT { get; set; }

        public double FrReg { get; set; }
        public double FrOT { get; set; }
        public double FrDT { get; set; }

        public double SaReg { get; set; }
        public double SaOT { get; set; }
        public double SaDT { get; set; }

        public double SuReg { get; set; }
        public double SuOT { get; set; }
        public double SuDT { get; set; }

        public List<Projects> DDProj { get; set; }

        public List<Tasks> DDTask { get; set; }
        public List<Resources> DDRes { get; set; }


    }
    public class Day
    {
        public string Name { get; set; }
        public string date { get; set; }
        public List<hourType> hours { get; set; }
    }
    public class hourType
        {
            public string htype { get; set; }
            public double hours { get; set; }
        }
    //}
}