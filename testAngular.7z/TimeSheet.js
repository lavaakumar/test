
var app = angular.module('app',
    [

        'ui.grid',
        //'ui.grid.pagination',
        'ui.grid.selection',
        'ui.grid.cellNav',
        'ui.grid.edit',
        'ui.grid.rowEdit',
        'ui.grid.saveState',
        'ui.grid.resizeColumns',
        'ui.grid.pinning',
        //'ui.grid.moveColumns',
        'ui.grid.exporter',
        'ui.grid.infiniteScroll',
        'ui.grid.importer',
        //'ui.grid.grouping'
    ]);


app.controller('gridCtrl', ['$scope', '$http', '$log', '$timeout', 'uiGridConstants', '$q', '$interval',
    function ($scope, $http, $log, $timeout, uiGridConstants, $q, $interval) {
      //  debugger;
        $scope.dgTimsheets = {
            enableRowSelection: true,
            enableSelectAll: true,
            selectionRowHeaderWidth: 35,
            rowHeight: 35,
            showGridFooter: true,
           
            
        };

        $scope.convertDate = function (str) {
          
            var date = new Date(str),
                mnth = ("0" + (date.getMonth() + 1)).slice(-2),
                day = ("0" + date.getDate()).slice(-2);
            return [date.getFullYear(), mnth, day].join("/");
        };
        var  NewRow = [];

       
        //(function (data) {
        //  //  debugger;
        //    $http({
        //        url: "TSRoute/loadPrj",
        //        dataType: 'json',
        //        method: 'GET',
        //        data: '',
        //        headers: {
        //            "Content-Type": "application/json"
        //        }
        //    })
        //     .success(function (data) {
        //       //  debugger;
        //         //$scope.dgTimsheets.columnDefs[7].editDropdownOptionsArray = data;
        //         $scope.Project = data


        //     })
        // .error(function (error) {
        //     debugger;
        //     alert(error);
        // });
        //})();

     
      
        //$scope.Task = [];
        $scope.NewRow = [];

      //  debugger;
        $scope.dgTimsheets = {
            enableFiltering:true,
          
            columnDefs: [
                //{
                //    name: "",
                //    field:"fake",
                //    cellTemplate: '<div class="ui-grid-cell-contents" >' +
                //    '<button value="Edit" ng-if="!row.inlineEdit.isEditModeOn" ng-click="row.inlineEdit.enterEditMode($event)">Delete</button>' +
                //    '<button value="Edit" ng-if="!row.inlineEdit.isEditModeOn" ng-click="row.inlineEdit.enterEditMode($event)">Edit</button>' +
                //    '<button value="Edit" ng-if="row.inlineEdit.isEditModeOn" ng-click="row.inlineEdit.saveEdit($event)">Update</button>' +
                //    '<button value="Edit" ng-if="row.inlineEdit.isEditModeOn" ng-click="row.inlineEdit.cancelEdit($event)">Cancel</button>' +
                //    '</div>',
                //     enableCellEdit: false,
                //            enableFiltering:false,
                //            enableSorting: false,
                //            showSortMenu : false,
                //            enableColumnMenu: false,
                //},
                {
                    name: 'Projects',width: '15%' , enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, //cellFilter: 'genderFilter',
                    editableCellTemplate: 'ui-grid/dropdownEditor',
                    editDropdownRowEntityOptionsArrayPath: 'DDProj',
                    // editDropdownIdLabel: 'ddId'
                    editDropdownvalueLabel: 'value'

                    //editDropdownOptionsArray: $scope.poject
                },
                {
                    name: 'Tasks', width: '15%', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, //cellFilter: 'genderFilter',
                    editableCellTemplate: 'ui-grid/dropdownEditor',
                    editDropdownRowEntityOptionsArrayPath: 'DDTask',
                    // editDropdownIdLabel: 'ddId'
                    editDropdownvalueLabel: 'value'

                    //editDropdownOptionsArray: $scope.poject
                },

                {
                    name: 'Resources', width: '5%', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, //cellFilter: 'genderFilter',
                    editableCellTemplate: 'ui-grid/dropdownEditor',
                    editDropdownRowEntityOptionsArrayPath: 'DDRes',
                    // editDropdownIdLabel: 'ddId'
                    editDropdownvalueLabel: 'value'

                    //editDropdownOptionsArray: $scope.poject
                },
              
                {
                    name: 'MoReg', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                    headerCellTemplate:"<div class = 'ui-grid-spilt-header-main'> <div class='ui-grid-split-merge-header' style='width:300%'><table class='ui-grid-header-table'><tbody><tr><td colspan='2'>Mon</td></tr></tbody></table></div>Reg</div>"
                },
                {
                    name: 'MoOT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                    headerCellTemplate: "<div class='ui-grid-spilt-header-main'>OT</div>"

                },
                  {
                      name: 'MoDT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class='ui-grid-spilt-header-main'>DT</div>"
                  },
                  {
                      name: 'TuReg', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class = 'ui-grid-spilt-header-main'> <div class='ui-grid-split-merge-header' style='width:300%'><table class='ui-grid-header-table'><tbody><tr><td colspan='2'>Tue</td></tr></tbody></table></div>Reg</div>"
                  },
                {
                    name: 'TuOT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                    headerCellTemplate: "<div class='ui-grid-spilt-header-main'>OT</div>"

                },
                  {
                      name: 'TuDT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class='ui-grid-spilt-header-main'>DT</div>"
                  },
                  {
                      name: 'WeReg', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class = 'ui-grid-spilt-header-main'> <div class='ui-grid-split-merge-header' style='width:300%'><table class='ui-grid-header-table'><tbody><tr><td colspan='2'>Wed</td></tr></tbody></table></div>Reg</div>"
                  },
                {
                    name: 'WeOT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                    headerCellTemplate: "<div class='ui-grid-spilt-header-main'>OT</div>"

                },
                  {
                      name: 'WeDT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class='ui-grid-spilt-header-main'>DT</div>"
                  },
                  {
                      name: 'ThReg', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class = 'ui-grid-spilt-header-main'> <div class='ui-grid-split-merge-header' style='width:300%'><table class='ui-grid-header-table'><tbody><tr><td colspan='2'>Thu</td></tr></tbody></table></div>Reg</div>"
                  },
                {
                    name: 'ThOT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                    headerCellTemplate: "<div class='ui-grid-spilt-header-main'>OT</div>"

                },
                  {
                      name: 'ThDT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class='ui-grid-spilt-header-main'>DT</div>"
                  },
                  {
                      name: 'FrReg', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class = 'ui-grid-spilt-header-main'> <div class='ui-grid-split-merge-header' style='width:300%'><table class='ui-grid-header-table'><tbody><tr><td colspan='2'>Fri</td></tr></tbody></table></div>Reg</div>"
                  },
                {
                    name: 'FrOT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                    headerCellTemplate: "<div class='ui-grid-spilt-header-main'>OT</div>"

                },
                  {
                      name: 'FrDT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class='ui-grid-spilt-header-main'>DT</div>"
                  },
                  {
                      name: 'SaReg', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class = 'ui-grid-spilt-header-main'> <div class='ui-grid-split-merge-header' style='width:300%'><table class='ui-grid-header-table'><tbody><tr><td colspan='2'>Sat</td></tr></tbody></table></div>Reg</div>"
                  },
                {
                    name: 'SaOT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                    headerCellTemplate: "<div class='ui-grid-spilt-header-main'>OT</div>"

                },
                  {
                      name: 'SaDT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class='ui-grid-spilt-header-main'>DT</div>"
                  },
                  {
                      name: 'SuReg', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class = 'ui-grid-spilt-header-main'> <div class='ui-grid-split-merge-header' style='width:300%'><table class='ui-grid-header-table'><tbody><tr><td colspan='2'>Sun</td></tr></tbody></table></div>Reg</div>"
                  },
                {
                    name: 'SuOT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                    headerCellTemplate: "<div class='ui-grid-spilt-header-main'>OT</div>"

                },
                  {
                      name: 'SuDT', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string",
                      headerCellTemplate: "<div class='ui-grid-spilt-header-main'>DT</div>"
                  },
                 {
                     name: 'Total', width: '10%', enableCellEdit: true, enableSorting: false, showSortMenu: false, enableFiltering: false, enableColumnMenu: false, type: "string"
                 },
                 
                  

              

            ],
            
            enableGridMenu: true,
            virtualizationThreshold: 60,
 
        }
    

        function Loadtasks(rowEntity) {
          
            $http({
                url: "TSRoute/loadTsk",
                method: 'GET',
                params: { u_prj: rowEntity.prj }

            })
          .success(function (data) {
            
              rowEntity.DDTask = data;
             // return data;
              //  
              //$scope.dgTimsheets.columnDefs[7].editDropdownOptionsArray = data;
              //$scope.Task = data

          })
      .error(function (error) {
        
          alert(error);
      });
        }
  //      $http({

  //          url: "TSRoute/loadRes",
  //          dataType: 'json',
  //          method: 'GET',
  //          data: '',
  //          headers: {
  //              "Content-Type": "application/json"
  //          }
  //      })
  //    .success(function (data) {
  //      //  debugger;
  //        //$scope.dgTimsheets.columnDefs[7].editDropdownOptionsArray = data;
  //        $scope.Resource = data

  //    })
  //.error(function (error) {
  //    debugger;
  //    alert(error);
  //});

        //debugger;
        //$scope.dgTimsheets.enableCellEditOnFocus = true;
     
            
      
     
        $http({
            url: "TSRoute/New",
            method: 'GET',
            params: {u_dt: "date string",u_plt:"EGA",u_blk:"ED"}
            //data: { u_dt: Weekdt, u_plt: plant, u_blk: block },
            //headers: {
            //    "Content-Type": "application/json"
            //}
        })
            .success(function (data) {
                
                //for (i = 0; i < data.length; i++)
                //{

                //    data[i].Projects = data[i].prj;
                //    data[i].ddprojects = $scope.Project;

                //    data[i].Tasks = data[i].tsk;
                //    data[i].ddTasks = $scope.Task;


                //    data[i].Resources = data[i].res;
                //    data[i].ddResources = $scope.Resource;
                //}
               
                $scope.dgTimsheets.data = data.slice(0, 15); //[data[0], data[1]];
                $scope.NewRow = angular.copy(data);
               // NewRow = data;
            })
        .error(function (error) {
          
            alert(error);
        });


      


        $scope.SendData = function (data) {
           
                $http({
                    url: "TSRoute/Save",
                dataType: 'json',
                method: 'POST',
                data: angular.toJson(data),
                headers: {
                    "Content-Type": "application/json"
                }
            }).success(function (response) {
                $scope.value = response;
            })
               .error(function (error) {
                 
                   alert(error);
               });
        }
       
        $scope.info = {};

        $scope.dgTimsheets.onRegisterApi = function (gridApi) {
            //set gridApi on scope
          //  debugger;
            $scope.gridApi = gridApi;

            gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                var msg = 'row selected ' + row.isSelected;
                $log.log(msg);
            });


           

            gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
                var msg = 'rows changed ' + rows.length;
                $log.log(msg);
            });

            gridApi.edit.on.afterCellEdit($scope, function (rowEntity, colDef, newValue, oldValue) {
                var selectedRows = $scope.gridApi.selection.getSelectedRows();

                var i;
                if (newValue != oldValue)
                {

                    rowEntity.state = "Changed";
                    //Get column
                   
                    debugger;
                    var rowCol = $scope.gridApi.cellNav.getFocusedCell().col.colDef.name;
                    if (rowCol == "Projects")
                    {
                        
                        rowEntity.prj = newValue;
                        rowEntity["Tasks"] = null;
                        $scope.gridApi.grid.columns
                       
                        Loadtasks(rowEntity);
                        //rowEntity.DDTask = task;
                    }
                    else if (rowCol == "Tasks") {
                        rowEntity.tsk = newValue;

                    }
                    else if (rowCol == "Resources") {
                        rowEntity.res = newValue;

                    }
                  
                    //$scope.gridOptions.ngGrid.rowMap.indexOf(rowItem.rowIndex);
                    i = $scope.dgTimsheets.data.indexOf(rowEntity);
                    angular.forEach(selectedRows, function (item) {
                        item[rowCol] = rowEntity[rowCol];// $scope.convertDate(rowEntity[rowCol]);
                        item.state = "Changed";
                        item.isDirty = false;
                        item.isError = false;
                    });

                }

                debugger;
                if (i === $scope.dgTimsheets.data.length - 1) 
                    {
                        
                    $scope.dgTimsheets.data.push(angular.copy($scope.NewRow[0]));
                    }
                    
                

            });

            gridApi.rowEdit.on.saveRow($scope, function (rowEntity) {
               
                // create a fake promise - normally you'd use the promise returned by $http or $resource
                //Get all selected rows
                var selectedRows = $scope.gridApi.selection.getSelectedRows();
                //var rowCol = $scope.gridApi.cellNav.getFocusedCell().col.colDef.name;
                var promise = $q.defer();
                $scope.gridApi.rowEdit.setSavePromise(rowEntity, promise.promise);

                $interval(function () {
                    //if (rowEntity.gender === 'male') {
                    //    promise.reject();
                    //} else {
                    //    promise.resolve();
                    //}
                    promise.resolve();
                }, 3000, 1);
            })


        };
      
    }])

//.filter('fitlerprj', function () {
//    var genderHash = {
//        1: 'Bachelor',
//        2: 'Nubile',
//        3: 'Married'
//    };

//    return function(input) {
//        if (!input){
//            return '';
//        } else {
//            return genderHash[input];
//        }
//    };
//});

//debugger;




